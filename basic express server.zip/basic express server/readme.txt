How to Run This 

1  Open terminal and go to this project folder
   cd express-server

2  Initialize the project (if not already done)
   npm init -y

3  Install express module
   npm install express

4  Run the server
   node index.js

5  Open your browser and go to
   http://localhost:3000/

You will see the message: Hello MERN Stack